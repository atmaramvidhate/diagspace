package com.diagknowlogy.spring.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class MatchedProblem implements Serializable {

	private static final long serialVersionUID = -1397511629L;
	
	String					number;
	String					description;
	String					confidenceLevel;
	ProgressLevel			progressLevel;
	KPI						kpi;
	String					rootCause;
	HashMap <String, List<Feedback>>  solutions;
	boolean					solutionAvailable;
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getConfidenceLevel() {
		return confidenceLevel;
	}
	public void setConfidenceLevel(String confidenceLevel) {
		this.confidenceLevel = confidenceLevel;
	}
	public ProgressLevel getProgressLevel() {
		return progressLevel;
	}
	public void setProgressLevel(ProgressLevel progressLevel) {
		this.progressLevel = progressLevel;
	}
	public KPI getKpi() {
		return kpi;
	}
	public void setKpi(KPI kpi) {
		this.kpi = kpi;
	}
	
}
