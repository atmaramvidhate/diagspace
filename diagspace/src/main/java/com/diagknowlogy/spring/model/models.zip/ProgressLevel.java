package com.diagknowlogy.spring.model;

public enum ProgressLevel {
	NOT_EXPLORED_YET,
	EXPLOER_FURTHER,
	DEAD_END
}
