package com.diagknowlogy.spring.model;

public enum SymptomStatus {
	NORMAL,
	WAY_BELOW_NORMAL,
	WAY_ABOVE_NORMAL
}
