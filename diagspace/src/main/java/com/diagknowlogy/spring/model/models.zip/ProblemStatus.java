package com.diagknowlogy.spring.model;

public enum ProblemStatus {
	NEW,
	ASSIGNED,
	IN_PROGRESS,
	RESOLVED,
	OBSOLETE
}
