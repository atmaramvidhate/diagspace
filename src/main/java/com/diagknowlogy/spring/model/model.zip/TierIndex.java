package com.diagknowlogy.spring.model;

public class TierIndex {
	String	tierName;
	int 	index;
	long	anamolyIndex;
	
	public String getTierName() {
		return tierName;
	}
	public void setTierName(String tierName) {
		this.tierName = tierName;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}

}
